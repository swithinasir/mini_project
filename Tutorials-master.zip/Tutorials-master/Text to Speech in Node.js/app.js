// Import dependencies
const say = require("say");

// Use default system voice and speed
say.speak("Today will make node speak");

// // Set the speed
// say.speak("Hello!", "", 0.5);

// Stop the text currently being spoken
// say.stop();

// Export Voice to file
// const filename = "hello.wav";
// say.export("Hello!", "", 0.75, filename, function (err) {
//     if (err) {
//         return console.error(err);
//     }

//     console.log(`Text has been saved to ${filename}`);
// });
