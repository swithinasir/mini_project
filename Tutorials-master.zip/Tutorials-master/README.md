# General info
All the smaller projects I've done in tutorials, on my YouTube channel [Vincent Lab.](https://www.youtube.com/channel/UCMA8gVyu_IkVIixXd2p18NQ)