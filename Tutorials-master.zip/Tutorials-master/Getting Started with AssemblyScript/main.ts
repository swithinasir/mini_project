import { log } from "./utils";
export function printName(name: string): void {
    log("Hello " + name + "! ");
}